import tkinter as tk
from tkinter import filedialog, messagebox
import xml.etree.ElementTree as ET
import os

def extract_place_text(xml_files):
    place_texts = []
    for file in xml_files:
        try:
            tree = ET.parse(file)
            root = tree.getroot()
            for place in root.iter('PLACE'):
                place_texts.append(place.text)
        except ET.ParseError:
            messagebox.showerror("Hiba", f"Hiba történt az XML fájl feldolgozása során: {file}")
    return place_texts

def save_to_file(texts, output_path):
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            for text in texts:
                f.write(f"{text}\n")
        messagebox.showinfo("Siker", f"A fájl sikeresen mentésre került: {output_path}")
    except Exception as e:
        messagebox.showerror("Hiba", f"Hiba történt a fájl mentése során: {str(e)}")

def browse_files():
    file_paths = filedialog.askopenfilenames(filetypes=[("XML files", "*.xml")])
    if file_paths:
        place_texts = extract_place_text(file_paths)
        if place_texts:
            output_path = os.path.join(r"C:\\Users\\G3909\\Desktop\\SAPLogon_autorun", "forras.txt")
            save_to_file(place_texts, output_path)
        else:
            messagebox.showinfo("Info", "Nem találtunk '<PLACE>' tegek közti karaktersorokat.")

# GUI setup
root = tk.Tk()
root.title("XML PLACE Extractor")

frame = tk.Frame(root, padx=10, pady=10)
frame.pack(padx=10, pady=10)

browse_button = tk.Button(frame, text="Tallózás...", command=browse_files)
browse_button.pack()

root.mainloop()
