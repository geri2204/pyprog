from pywinauto import Desktop, Application
import time

def GetWindow(app, name):
    """Find a window by its partial title within the application."""
    for win in app.windows():
        if name in win.window_text() and win.window_text() != "":
            return win
    return None

def identify_controls(window):
    """Print control identifiers of the given window."""
    if window:
        try:
            window.child_window().print_control_identifiers()
        except Exception as e:
            print(f"Error identifying: {e}")
    else:
        print("Nincs mit identify-olni")

def wait_for_window(app, target_title, timeout=60):
    """Wait for a window with the specified title to appear within the application."""
    window = None
    start_time = time.time()
    while not window and time.time() - start_time < timeout:
        window = GetWindow(app, target_title)
        if not window:
            time.sleep(1)
    return window

def main():
    # Start SAP Logon
    app = Application(backend="win32").start(r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe")
    print("SAP Logon elindult. Várakozás a célablakra...")

    # Wait for the first target window
    target_title = "EMP(1)/102 Bekötés megjelenítése: kezdő kép"
    window = wait_for_window(app, target_title)
    
    if window:
        print(f"Célablak megtalálva: {window.window_text()}")
        window.set_focus()
        identify_controls(window)
    else:
        print("Célablak nem található.")
        return

    # Wait for the second target window
    target_title = "EMP(1)/102 Data Finder(adatkereső): Közműbekötés keresése"
    window = wait_for_window(app, target_title)
    
    if window:
        print(f"Célablak megtalálva: {window.window_text()}")
        window.set_focus()
        identify_controls(window)
    else:
        print("Célablak nem található.")
        return

    # Wait for the third target window
    target_title = "EMP(1)/102 Bekötés megjelenítése:"
    window = wait_for_window(app, target_title)
    
    if window:
        print(f"Célablak megtalálva: {window.window_text()}")
        window.set_focus()
        identify_controls(window)
    else:
        print("Célablak nem található.")
        return

if __name__ == "__main__":
    main()
