"""
tkinter: A Python beépített GUI könyvtára.
os: Fájl- és mappaoperációkhoz használt modul.
shutil: Fájl- és mappaoperációkhoz használt modul, ideértve a fájlok áthelyezését is.
datetime: Az aktuális idő lekérdezésére és formázására szolgáló modul.

"""




import tkinter as tk
import os
import shutil
from datetime import datetime

# Gombnyomás esemény kezelő: Beküld
def submit_button_click():
    
    name = name_entry.get()     # Ügyintéző nevének beolvasása az input mezőből
    code = code_entry.get()     # Ügyintéző kódjának beolvasása az input mezőből
    
    # Monogram készítése
    name_parts = name.split()   # Ügyintéző teljes nevének szétbontása szóköz mentén
    monogram = ''.join([part[0].upper() for part in name_parts])    # Monogram létrehozása
    
    # Üzenet megjelenítése
    result_label.config(text=f"Hello, {name}! A monogramod: {monogram}")    # Eredmény kiírása a GUI-ba
    
    # Felhasználó által megadott mappa útvonala
    folder_path = folder_entry.get()        # Mappa útvonalának beolvasása az input mezőből
    
    # Meghatározzuk a formázott dátumot
    current_time = datetime.now().strftime("%Y%m%d_%H%M")    # Aktuális idő formázása
    
    # Mappa neve a formázott dátum alapján
    folder_name = f"{current_time}"         # Mappa nevének létrehozása a formázott időből
    
    # Teljes mappa útvonala
    folder_dir = os.path.join(folder_path, folder_name)     # Teljes mappa útvonal összeállítása
    
    # Ellenőrizzük, hogy létezik-e már a mappa, ha nem, létrehozzuk
    if not os.path.exists(folder_dir):      # Ha még nem létezik a mappa, létrehozzuk
        os.makedirs(folder_dir)
        print(f"A(z) '{folder_name}' nevű mappa létrehozva itt: '{folder_dir}'")
    else:                                   # Ha már létezik a mappa, erről tájékoztatjuk a felhasználót
        print(f"A(z) '{folder_name}' nevű mappa már létezik itt: '{folder_dir}'")
    
    # Fájl útvonalának meghatározása a létrehozott mappában
    file_path = os.path.join(folder_dir, 'belep.txt')
    
    # Adatok írása a belep.txt fájlba
    with open(file_path, 'w') as file:      # Adatok írása a belep.txt fájlba
        file.write(f"Ügyintéző neve: {name}\n")
        file.write(f"Monogram: {monogram}\n")
        file.write(f"Kód: {code}\n")
        file.write(f"Dátum és idő: {current_time}\n")




"""
----------------------------------------------------------------------------------------
submit_button_click(): Ez a függvény fut le, amikor a "Beküld" gombra kattintanak. 
Beolvassa az ügyintéző nevét és kódját, létrehozza a monogramot, majd létrehoz egy 
új mappát a felhasználó által megadott útvonalon a formázott idővel. Ezután létrehoz 
egy belep.txt fájlt a mappában, amelybe kiírja az ügyintéző adatait és a dátumot.
"""
# Gombnyomás esemény kezelő: Bemásol
def copy_button_click():
    # Felhasználó által megadott célmappa útvonala
    folder_path = folder_entry.get()        # Célmappa útvonalának beolvasása az input mezőből
    
    # Meghatározzuk a formázott dátumot
    current_time = datetime.now().strftime("%Y%m%d_%H%M")    # Aktuális idő formázása
    
    # Mappa neve a formázott dátum alapján
    folder_name = f"{current_time}"                         # Mappa nevének létrehozása a formázott időből
    
    # Teljes mappa útvonala
    folder_dir = os.path.join(folder_path, folder_name)     # Teljes mappa útvonal összeállítása
    
    # Ellenőrizzük, hogy létezik-e a mappa
    if os.path.exists(folder_dir):                          # Ha létezik a cél mappa
        # Felhasználó által választott forrás mappa útvonala
        source_folder = source_folder_entry.get()           # Forrás mappa útvonalának beolvasása
        
        # Ha a felhasználó nem adott meg forrás mappa útvonalat, hibát jelezünk
        if not source_folder:
            print("Kérem adjon meg egy forrás mappa útvonalat!")
            return
        
        # Ha a megadott mappa nem létezik, hibát jelezünk
        if not os.path.exists(source_folder):
            print(f"A(z) '{source_folder}' mappa nem létezik!")
            return
        
        try:
            # Iterálunk az összes fájlon és mappán a forrás mappában
            for item in os.listdir(source_folder):
                source_item = os.path.join(source_folder, item)
                target_item = os.path.join(folder_dir, item)
                
                # Ha fájl, akkor áthelyezzük
                if os.path.isfile(source_item):
                    shutil.move(source_item, target_item)
                    print(f"A {item} fájl áthelyezve ide: '{target_item}'")
                
                # Ha mappa, akkor rekurzívan áthelyezzük
                elif os.path.isdir(source_item):
                    shutil.move(source_item, target_item)
                    print(f"A {item} mappa áthelyezve ide: '{target_item}' (rekurzívan)")
        
        except Exception as e:
            print(f"Hiba történt az áthelyezés közben: {str(e)}")
            
    else:
        print(f"A(z) '{folder_name}' nevű mappa nem létezik itt: '{folder_dir}'")






"""
-------------------------------------------------------------------------------------------------
copy_button_click(): Ez a függvény fut le, amikor a "Bemásol" gombra kattintanak. 
Beolvassa a célmappa útvonalát, majd a forrás mappa útvonalát, 
és áthelyezi a forrás mappa összes fájlját és almappáját a célmappa útvonalán létrehozott új mappába. 
Ha nem adnak meg forrás mappa útvonalat, vagy ha nem létezik a megadott forrás mappa, hibát jelez.
"""

# Fő Tkinter ablak létrehozása
root = tk.Tk()
root.title("Ügyintéző adatok és fájl áthelyezés")

# Mappa útvonal megadása
folder_label = tk.Label(root, text="Mappa útvonala:")
folder_label.pack()
folder_entry = tk.Entry(root)
folder_entry.pack()

# Forrás mappa útvonal megadása
source_folder_label = tk.Label(root, text="Forrás mappa útvonala:")
source_folder_label.pack()
source_folder_entry = tk.Entry(root)
source_folder_entry.pack()

# Név megadása
name_label = tk.Label(root, text="Az ügyintéző teljes neve:")
name_label.pack()
name_entry = tk.Entry(root)
name_entry.pack()

# Kód megadása
code_label = tk.Label(root, text="Az ügyintéző kódja:")
code_label.pack()
code_entry = tk.Entry(root)
code_entry.pack()

# Gomb létrehozása: Beküld
submit_button = tk.Button(root, text="Beküld", command=submit_button_click)
submit_button.pack()

# Gomb létrehozása: Bemásol
copy_button = tk.Button(root, text="Bemásol", command=copy_button_click)
copy_button.pack()

# Eredmény kiírása
result_label = tk.Label(root, text="")
result_label.pack()

# Tkinter fő hurok
root.mainloop()
