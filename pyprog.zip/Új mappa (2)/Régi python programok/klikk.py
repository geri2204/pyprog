from pywinauto import Desktop
import time
from pywinauto.keyboard import send_keys

# Replace this with the exact title or partial title of the window you're interested in
target_title = "EMP(1)/102 Bekötés megjelenítése: kezdő kép"

# List all open windows
for window in Desktop(backend="win32").windows():
    print(f"Window Title: {window.window_text()}")
    if target_title in window.window_text():
        print(f"Found target window: {window.window_text()}")
        window.set_focus()
        time.sleep(1)  # Observe the target window

        # Send Ctrl+F key combination
        send_keys('^f')  # '^' is the symbol for Ctrl

        print("Ctrl+F key combination sent.")
        break  # Exit loop once target window is found and focused

print("Finished processing windows.")
