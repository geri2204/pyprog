import openpyxl
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

# Globális változó a legutóbbi módosított fájl elérési útjához
modified_file_path = None

def process_file_replace(file_path, agent, old_values, new_values):
    global modified_file_path
    
    # Load the Excel file
    workbook = openpyxl.load_workbook(file_path)
    
    # Define the sheets to be processed
    sheets_to_process = ['ALAP', 'CSATLAKOZASI_PONT_ADATOK', 'SPEC_JELLEMZOK', 
                         'TERMEK_MENNYISEG', 'KOMMUNIKACIO (KAPCSOLATTARTO)', 
                         'KOMMUNIKACIO (FOGYASZTO)']
    
    # Read old and new values from text widgets
    old_values = old_values.strip().split('\n')
    new_values = new_values.strip().split('\n')
    
    if len(old_values) != len(new_values):
        messagebox.showerror("Error", "Old values and new values must have the same number of entries.")
        return

    value_map = dict(zip(old_values, new_values))
    
    # Process each sheet
    for sheet_name in sheets_to_process:
        if sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            for row in sheet.iter_rows(min_row=2, min_col=1, max_col=1):
                cell = row[0]
                if cell.value in value_map:
                    cell.value = value_map[cell.value]
                    
            # Add 'UB1' to column 'B' if 'A' has data (only for 'ALAP' sheet)
            if sheet_name == 'ALAP':
                for row in sheet.iter_rows(min_row=2, min_col=1, max_col=2):
                    cell_a = row[0]
                    cell_b = row[1]
                    if cell_a.value is not None:
                        cell_b.value = 'UB1'
    
    # Save the new file with the appropriate suffix
    suffix = '_HG' if agent == 'Hafner Gergő' else '_KB'
    modified_file_path = file_path.replace(".xlsx", f"{suffix}.xlsx")
    workbook.save(modified_file_path)
    messagebox.showinfo("Success", f"File processed and saved as {modified_file_path}")

def process_file_delete(file_path, values_to_delete):
    # Load the Excel file
    workbook = openpyxl.load_workbook(file_path)
    
    # Define the sheets to be processed
    sheets_to_process = ['ALAP', 'CSATLAKOZASI_PONT_ADATOK', 'SPEC_JELLEMZOK', 
                         'TERMEK_MENNYISEG', 'KOMMUNIKACIO (KAPCSOLATTARTO)', 
                         'KOMMUNIKACIO (FOGYASZTO)']
    
    # Read values to delete from text widget
    values_to_delete = [val.strip() for val in values_to_delete.strip().split('\n') if val.strip()]
    
    for sheet_name in sheets_to_process:
        if sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            rows_to_delete = []
            for row in sheet.iter_rows(min_row=2, min_col=1, max_col=1):
                cell = row[0]
                if cell.value in values_to_delete:
                    rows_to_delete.append(cell.row)
            
            # Sort the rows in reverse order to avoid indexing issues when deleting
            for row in sorted(rows_to_delete, reverse=True):
                sheet.delete_rows(row)
    
    # Save the new file with a suffix
    new_file_path = file_path.replace(".xlsx", "_1.xlsx")
    workbook.save(new_file_path)
    messagebox.showinfo("Success", f"File processed and saved as {new_file_path}")

def open_file():
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if file_path:
        file_path_var.set(file_path)

def run_processing_replace():
    global modified_file_path
    
    file_path = file_path_var.get()
    if not file_path:
        messagebox.showerror("Error", "Please select a file.")
        return
    
    agent = agent_var.get()
    old_values = old_values_text.get("1.0", tk.END)
    new_values = new_values_text.get("1.0", tk.END)
    
    if not old_values.strip() or not new_values.strip():
        messagebox.showerror("Error", "Please enter both old and new values.")
        return
    
    process_file_replace(file_path, agent, old_values, new_values)
    # Set the modified file path for the delete operation
    file_path_var.set(modified_file_path)

def run_processing_delete():
    file_path = file_path_var.get()
    if not file_path:
        messagebox.showerror("Error", "Please select a file.")
        return
    
    rows_to_delete = rows_to_delete_text.get("1.0", tk.END)
    
    if not rows_to_delete.strip():
        messagebox.showerror("Error", "Please enter values to delete.")
        return
    
    process_file_delete(file_path, rows_to_delete)

# Create the main window
root = tk.Tk()
root.title("Excel File Processor")

# Create tab control
tab_control = ttk.Notebook(root)
tab_replace = ttk.Frame(tab_control)
tab_delete = ttk.Frame(tab_control)
tab_control.add(tab_replace, text="Replace References")
tab_control.add(tab_delete, text="Delete Rows")
tab_control.pack(expand=1, fill="both")

# File selection for Replace References tab
file_path_var = tk.StringVar()
tk.Label(tab_replace, text="Select Excel file:").grid(row=0, column=0, padx=10, pady=5)
tk.Entry(tab_replace, textvariable=file_path_var, width=50).grid(row=0, column=1, padx=10, pady=5)
tk.Button(tab_replace, text="Browse", command=open_file).grid(row=0, column=2, padx=10, pady=5)

# Replace References tab
# Agent selection
tk.Label(tab_replace, text="Select agent:").grid(row=1, column=0, padx=10, pady=5)
agent_var = tk.StringVar()
agent_var.set("Hafner Gergő")
tk.OptionMenu(tab_replace, agent_var, "Hafner Gergő", "Kálló Bence").grid(row=1, column=1, padx=10, pady=5)

# Old values
tk.Label(tab_replace, text="Old values:").grid(row=2, column=0, padx=10, pady=5)
old_values_text = tk.Text(tab_replace, height=10, width=25)
old_values_text.grid(row=2, column=1, padx=10, pady=5)

# New values
tk.Label(tab_replace, text="New values:").grid(row=2, column=2, padx=10, pady=5)
new_values_text = tk.Text(tab_replace, height=10, width=25)
new_values_text.grid(row=2, column=3, padx=10, pady=5)

# Process button for Replace References tab
tk.Button(tab_replace, text="Process", command=run_processing_replace).grid(row=3, column=1, columnspan=2, pady=10)

# Delete Rows tab
# Rows to delete
tk.Label(tab_delete, text="Values to delete (from column A):").grid(row=1, column=0, padx=10, pady=5)
rows_to_delete_text = tk.Text(tab_delete, height=10, width=25)
rows_to_delete_text.grid(row=1, column=1, padx=10, pady=5)

# Process button for Delete Rows tab
tk.Button(tab_delete, text="Process", command=run_processing_delete).grid(row=2, column=1, pady=10)

root.mainloop()
