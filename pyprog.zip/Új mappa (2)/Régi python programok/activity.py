import pyautogui
import time
import math
import keyboard  # A keyboard csomag figyeli a billentyűleütéseket
import tkinter as tk

def show_warning_message():
    # Létrehozunk egy átlátszó ablakot
    root = tk.Tk()
    root.title("Warning!")
    root.geometry("300x50+{}+{}".format(
        int((root.winfo_screenwidth() - 300) / 2),
        int((root.winfo_screenheight() - 50) / 2)
    ))
    root.attributes('-alpha', 0.7)  # Átlátszóság beállítása
    root.attributes('-topmost', True)  # Az ablak mindig a tetején marad

    label = tk.Label(root, text="Warning! An automatic process runs. Exit: Press: S", font=("Arial", 8))
    label.pack(expand=True)  # Középre helyezés

    return root

def move_cursor_in_circle(radius=100, center=None, steps=100, interval=0.05):
    # A kurzor kezdő helyzetét vesszük alapértelmezett középpontnak
    if center is None:
        center = pyautogui.position()
    
    center_x, center_y = center

    # Figyelmeztető üzenet megjelenítése
    warning_window = show_warning_message()
    warning_window.update()  # Az ablak frissítése

    while True:
        for i in range(steps):
            # Ellenőrizzük, hogy megnyomták-e az "S" gombot
            if keyboard.is_pressed("s"):
                print("Megállítva a körmozgás.")
                warning_window.destroy()  # Az ablak bezárása
                return  # Kilép a függvényből, leállítva a ciklust
            
            # Számoljuk ki az új szöget, hogy körbe haladjunk
            angle = 2 * math.pi * i / steps
            # Számoljuk ki az új pozíciót a kör menténs
            new_x = center_x + int(radius * math.cos(angle))
            new_y = center_y + int(radius * math.sin(angle))
            
            # Mozgatás új pozícióra
            pyautogui.moveTo(new_x, new_y)
            time.sleep(interval)  # Rövid várakozás a folyamatos mozgáshoz

# Program futtatása
move_cursor_in_circle()
