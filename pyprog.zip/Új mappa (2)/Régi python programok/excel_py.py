import openpyxl
from openpyxl import load_workbook

# Fájl elérési út megadása
file_path = 'C:/Users/G3909/Desktop/py/test.xlsx'

# Munkafüzet betöltése
book = load_workbook(file_path)
sheet = book.active
cella = 'H8'
ertek='KKKKKKK'

# Eredeti érték kiírása
print(sheet[cella].value)

# Cella értékének módosítása
sheet[cella].value = ertek

# Munkafüzet mentése ugyanabba a fájlba
book.save(file_path)

# Betöltés és ellenőrzés a mentés után
book = load_workbook(file_path)
sheet = book.active
print(sheet[cella].value)