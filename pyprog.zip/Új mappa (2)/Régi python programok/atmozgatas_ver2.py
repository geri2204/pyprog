import tkinter as tk
from tkinter import ttk
import os
import shutil
from datetime import datetime
import openpyxl
from openpyxl import load_workbook

# Mappa útvonalak
folders = {
    "EFM_normal_csere_kezeles_S03": r"Z:\Alkalmazasok\ÉMÁSZ SAP\prod\emaszAmb\adatcsere2_atm\EFM_normal_csere_kezeles_S03\Beerkezett",
    "FHV_megszuntetes_FM1": r"Z:\Alkalmazasok\ÉMÁSZ SAP\prod\emaszAmb\adatcsere2_atm\FHV_megszuntetes_FM1\Beerkezett",
    "Ideiglenes_bekapcsolas_UB1": r"Z:\Alkalmazasok\ÉMÁSZ SAP\prod\emaszAmb\adatcsere2_atm\Ideiglenes_bekapcsolas_UB1\Beerkezett",
    "Ujbekapcsolas_UB1": r"Z:\Alkalmazasok\ÉMÁSZ SAP\prod\emaszAmb\adatcsere2_atm\Ujbekapcsolas_UB1\Beerkezett"
}

source_folders = {
    "EFM_normal_csere_kezeles_S03": r"Z:\Alkalmazasok\ÉMÁSZ SAP\prod\emaszAmb\adatcsere2_atm\EFM_normal_csere_kezeles_S03\Kiosztott",
    "FHV_megszuntetes_FM1": r"Z:\Alkalmazasok\ÉMÁSZ SAP\prod\emaszAmb\adatcsere2_atm\FHV_megszuntetes_FM1\Kiosztott",
    "Ideiglenes_bekapcsolas_UB1": r"Z:\Alkalmazasok\ÉMÁSZ SAP\prod\emaszAmb\adatcsere2_atm\Ideiglenes_bekapcsolas_UB1\Kiosztott",
    "Ujbekapcsolas_UB1": r"Z:\Alkalmazasok\ÉMÁSZ SAP\prod\emaszAmb\adatcsere2_atm\Ujbekapcsolas_UB1\Kiosztott"
}

temp_folder_path = r"M:\TEAMS\100_GI\130_EFO\132_EFO_EFO\6_ADATCSERE\Átmeneti adatcsere\XML_KONVERTALASHOZ"

# Gombnyomás esemény kezelő: Beküld
def submit_button_click():
    source_folder_key = folder_combo.get()  
    source_folder_path = source_folders[source_folder_key]  

    current_time = datetime.now().strftime("%Y%m%d_%H%M")  
    folder_name = f"{current_time}"  

    folder_dir = os.path.join(source_folder_path, folder_name)  

    if not os.path.exists(folder_dir):  
        os.makedirs(folder_dir)
        print(f"A(z) '{folder_name}' nevű mappa létrehozva itt: '{folder_dir}'")
    else:  
        print(f"A(z) '{folder_name}' nevű mappa már létezik itt: '{folder_dir}'")

    result_label.config(text=f"A(z) '{folder_name}' nevű mappa létrehozva itt: '{folder_dir}'")

# Gombnyomás esemény kezelő: Bemásol
def copy_button_click():
    folder_key = folder_combo.get()  
    destination_path = source_folders[folder_key]  

    current_time = datetime.now().strftime("%Y%m%d_%H%M")  
    folder_name = f"{current_time}"  

    destination_folder = os.path.join(destination_path, folder_name)  

    if os.path.exists(destination_folder):  
        source_folder_key = source_folder_combo.get()  
        source_folder = folders[source_folder_key]  

        if not os.path.exists(source_folder):
            print(f"A(z) '{source_folder}' mappa nem létezik!")
            return

        try:
            for item in os.listdir(source_folder):
                source_item = os.path.join(source_folder, item)
                target_item = os.path.join(destination_folder, item)

                if os.path.isfile(source_item):
                    shutil.move(source_item, target_item)
                    print(f"A {item} fájl áthelyezve ide: '{target_item}'")

                elif os.path.isdir(source_item):
                    shutil.move(source_item, target_item)
                    print(f"A {item} mappa áthelyezve ide: '{target_item}' (rekurzívan)")

        except Exception as e:
            print(f"Hiba történt az áthelyezés közben: {str(e)}")

    else:
        print(f"A(z) '{folder_name}' nevű mappa nem létezik itt: '{destination_folder}'")

# Gombnyomás esemény kezelő: Excel cella módosítása
def modify_excel_cell():
    file_path = excel_file_entry.get()  
    cella = cell_entry.get()  
    ertek = value_entry.get()  

    if not file_path.endswith(('.xlsx', '.xlsm', '.xltx', '.xltm')):
        excel_result_label.config(text="Nem támogatott fájlformátum!")
        return

    if not os.path.exists(file_path):
        excel_result_label.config(text="A megadott fájl nem létezik!")
        return

    try:
        book = load_workbook(file_path)
        sheet = book.active

        original_value = sheet[cella].value
        print(f"Eredeti érték a(z) {cella} cellában: {original_value}")

        sheet[cella].value = ertek

        book.save(file_path)

        book = load_workbook(file_path)
        sheet = book.active
        modified_value = sheet[cella].value
        print(f"Módosított érték a(z) {cella} cellában: {modified_value}")

        excel_result_label.config(text=f"Módosított érték a(z) {cella} cellában: {modified_value}")

    except Exception as e:
        print(f"Hiba történt: {str(e)}")
        excel_result_label.config(text=f"Hiba történt: {str(e)}")

# Gombnyomás esemény kezelő: Áthelyezés a temp mappába
def move_to_temp():
    folder_key = folder_combo.get()  
    source_path = source_folders[folder_key]  

    current_time = datetime.now().strftime("%Y%m%d_%H%M")  
    folder_name = f"{current_time}"  

    source_folder = os.path.join(source_path, folder_name)  

    if os.path.exists(source_folder):  
        try:
            for item in os.listdir(source_folder):
                source_item = os.path.join(source_folder, item)
                target_item = os.path.join(temp_folder_path, item)

                if os.path.isfile(source_item):
                    shutil.copy(source_item, target_item)
                    print(f"A {item} fájl másolva ide: '{target_item}'")

                elif os.path.isdir(source_item):
                    shutil.copytree(source_item, target_item)
                    print(f"A {item} mappa másolva ide: '{target_item}' (rekurzívan)")

            temp_result_label.config(text=f"Az összes fájl és mappa másolva ide: '{temp_folder_path}'")

        except Exception as e:
            print(f"Hiba történt a másolás közben: {str(e)}")
            temp_result_label.config(text=f"Hiba történt: {str(e)}")

    else:
        print(f"A(z) '{folder_name}' nevű mappa nem létezik itt: '{source_folder}'")
        temp_result_label.config(text=f"A(z) '{folder_name}' nevű mappa nem létezik itt: '{source_folder}'")

# Fő Tkinter ablak létrehozása
root = tk.Tk()
root.title("Ügyintéző adatok és fájl áthelyezés")

# Ikont beállítása
root.iconbitmap(r'C:\Users\G3909\Desktop\icon.ico')

# Notebook (tabok) létrehozása
notebook = ttk.Notebook(root)
notebook.pack(pady=10, expand=True)

# Fül 1: Adatok beküldése
frame1 = ttk.Frame(notebook, width=400, height=280)
frame1.pack(fill='both', expand=True)

# Fül 2: Excel cella módosítása
frame3 = ttk.Frame(notebook, width=400, height=280)
frame3.pack(fill='both', expand=True)

notebook.add(frame1, text='Adatok beküldése')
notebook.add(frame3, text='Excel cella módosítása')

# Fül 1: Adatok beküldése
folder_label = tk.Label(frame1, text="Beérkezett üzenet helye:")
folder_label.pack()
folder_combo = ttk.Combobox(frame1, values=list(folders.keys()), width=80)
folder_combo.pack()

source_folder_label = tk.Label(frame1, text="Kiosztott üzenet helye:")
source_folder_label.pack()
source_folder_combo = ttk.Combobox(frame1, values=list(source_folders.keys()), width=80)
source_folder_combo.pack()

submit_button = tk.Button(frame1, text="Dátumbélyegzett mappa létrehozása", command=submit_button_click)
submit_button.pack()

copy_button = tk.Button(frame1, text="Összes fájl áthelyezése a 'Kiosztott' mappába", command=copy_button_click)
copy_button.pack()

move_button = tk.Button(frame1, text="Másolás az 'XML_KONVERTÁLÁSHOZ' mappába", command=move_to_temp)
move_button.pack()

result_label = tk.Label(frame1, text="")
result_label.pack()

temp_result_label = tk.Label(frame1, text="")
temp_result_label.pack()

# Fül 2: Excel cella módosítása
excel_file_label = tk.Label(frame3, text="Excel fájl útvonala:")
excel_file_label.pack()
excel_file_entry = tk.Entry(frame3)
excel_file_entry.pack()

cell_label = tk.Label(frame3, text="Cella:")
cell_label.pack()
cell_entry = tk.Entry(frame3)
cell_entry.pack()

value_label = tk.Label(frame3, text="Új érték:")
value_label.pack()
value_entry = tk.Entry(frame3)
value_entry.pack()

modify_button = tk.Button(frame3, text="Módosít", command=modify_excel_cell)
modify_button.pack()

excel_result_label = tk.Label(frame3, text="")
excel_result_label.pack()

# Tkinter fő eseményhurok
root.mainloop()
