import tkinter as tk
from tkinter import filedialog, messagebox
import openpyxl
import os
import re

def delete_rows_with_numbers(file_path, numbers, user):
    # Load the workbook
    wb = openpyxl.load_workbook(file_path)
    
    # Sheets to process
    sheets_to_process = [
        'ALAP', 'CSATLAKOZÁSI_PONT_ADATOK', 'SPEC_JELLEMZOK', 
        'TERMEK_MENNYISEG', 'KOMMUNIKACIO (KAPCSOLATTARTO)', 'KOMMUNIKACIO (FOGYASZTO)'
    ]
    
    for sheet_name in sheets_to_process:
        if sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows_to_delete = set()  # Use a set to avoid duplicates
            for number in numbers:
                for row in ws.iter_rows(min_col=1, max_col=1):
                    for cell in row:
                        if cell.value == number:
                            rows_to_delete.add(cell.row)
            
            for row in sorted(rows_to_delete, reverse=True):
                ws.delete_rows(row, 1)

    # Save the workbook with the modified name
    base_path = "C:\\Users\\G3909\\Desktop"
    base_name = os.path.basename(file_path)
    
    if user == "Hafner Gergő":
        suffix = "_HG"
    elif user == "Kálló Bence":
        suffix = "_KB"
    
    match = re.match(r"^(.*)(_HG|_KB)?(_\d+)?(\.xlsx)$", base_name)
    if match:
        name, _, number_suffix, ext = match.groups()
        if number_suffix:
            new_number = int(number_suffix[1:]) + 1
        else:
            new_number = 1
        new_name = f"{name}{suffix}_{new_number}{ext}"
    else:
        new_name = f"{base_name}{suffix}_1.xlsx"
    
    new_path = os.path.join(base_path, new_name)
    
    wb.save(new_path)
    messagebox.showinfo("Info", f"The rows have been deleted and the file is saved as {new_name}.")

def browse_file():
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if file_path:
        file_entry.delete(0, tk.END)
        file_entry.insert(0, file_path)

def process_file():
    file_path = file_entry.get()
    numbers = number_entry.get().split(';')
    user = user_var.get()
    
    if not file_path or not numbers or not user:
        messagebox.showerror("Error", "Please provide the file, the numbers, and select a user.")
        return
    
    try:
        numbers = [int(number.strip()) for number in numbers if number.strip()]
        delete_rows_with_numbers(file_path, numbers, user)
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers separated by semicolons.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Create the main window
root = tk.Tk()
root.title("Delete Rows from Excel")

# Create and place the widgets
tk.Label(root, text="Excel file:").grid(row=0, column=0, padx=10, pady=10)
file_entry = tk.Entry(root, width=50)
file_entry.grid(row=0, column=1, padx=10, pady=10)
tk.Button(root, text="Browse", command=browse_file).grid(row=0, column=2, padx=10, pady=10)

tk.Label(root, text="Numbers (separated by ';'):").grid(row=1, column=0, padx=10, pady=10)
number_entry = tk.Entry(root, width=50)
number_entry.grid(row=1, column=1, padx=10, pady=10)

tk.Label(root, text="User:").grid(row=2, column=0, padx=10, pady=10)
user_var = tk.StringVar()
user_dropdown = tk.OptionMenu(root, user_var, "Hafner Gergő", "Kálló Bence")
user_dropdown.grid(row=2, column=1, padx=10, pady=10)

tk.Button(root, text="Process", command=process_file).grid(row=3, column=0, columnspan=3, pady=20)

# Run the main loop
root.mainloop()
