import pandas as pd
import tkinter as tk
from tkinter import filedialog, messagebox

# Munkalapok és oszlopok, amelyeket ki kell hagyni a másolás során
exclude_columns = {
    'ALAP': ['Üzenet kategóriája', 'A mérési pont típusa', 'Státusz kategória', 'Folyamat kód', 
             'Elosztó általi becslés', 'Szerződéskezelés kiegészítő információ', 'Azonosító', 
             'Megállapodás típus', 'Szerződéskötés / Vételezés jogcíme', 'Eljárás jogalapja', 
             'Objektum azonosító típus', 'Ügyfél fizetési módja', 'Ügyfél fajta', 'Jogi forma', 
             'Kapcsolat típus', 'Végszámla fizető fizetési módja', 'Végszámla fizető fajta', 
             'Jogi forma (végszámla fizető)', 'Jogi forma (fogyasztási hely)', 
             'Kapcsolattartó fajta', 'Jogi forma (kapcsolattartó)', 
             'Kapcsolat típus (kapcsolattartó)', 'Eltérő számlafogadó fajta', 
             'Jogi forma (ÜP levelezési cím)', 'Eltérő fizető fizetési módja', 'Eltérő fizető fajta', 
             'Jogi forma (eltérő fizető)', 'Műszaki szolgáltató fizető fizetési módja', 
             'Műszaki szolgáltató fizető fajta', 'Jogi forma (műszaki szolgáltató fizető)'],
    'SPEC_JELLEMZOK': ['Jellemző azonosító', 'Ügynökség', 'A profil típusa, ha profilozott és / vagy elosztói tarifa'],
    'TERMEK_MENNYISEG': ['Cselekvés igénylés', 'Mérőcsere esetén a le- és felszerelés megkülönböztetése', 
                         'Termék azonosító', 'Tétel szám típus', 'Kód lista', 'Mennyiségi azonosító', 'Mértékegység'],
    'KOMMUNIKACIO(KAPCSOLATTARTO)': ['Kommunikációs típus'],
    'KOMMUNIKACIO(FOGYASZTO)': ['Kommunikációs típus']
}

def process_file(reference_file, user_file):
    try:
        # Betöltjük a referenciaként szolgáló Excel fájlt
        reference_xls = pd.ExcelFile(reference_file)

        # Betöltjük a felhasználó által kiválasztott Excel fájlt
        user_xls = pd.ExcelFile(user_file)

        # Új Excel fájl létrehozása
        writer = pd.ExcelWriter(user_file.replace('.xlsx', '_mod.xlsx'), engine='openpyxl')

        missing_columns = []

        for sheet in reference_xls.sheet_names:
            if sheet in user_xls.sheet_names:
                ref_df = reference_xls.parse(sheet)
                user_df = user_xls.parse(sheet)

                # Az oszlopok közös metszetének megtalálása, figyelembe véve a kizárandó oszlopokat
                common_columns = [col for col in ref_df.columns if col in user_df.columns and col not in exclude_columns.get(sheet, [])]

                # Ellenőrizzük, ha van olyan oszlop, ami hiányzik a tallózott fájlból
                for col in ref_df.columns:
                    if col not in user_df.columns and col not in exclude_columns.get(sheet, []):
                        missing_columns.append(col)

                # Csak a közös oszlopokat tartalmazó adatokat másoljuk
                ref_df.update(user_df[common_columns])

                # Az eredményt mentjük az új Excel fájlba
                ref_df.to_excel(writer, sheet_name=sheet, index=False)
            else:
                # Ha nincs ilyen munkalap a tallózott fájlban, akkor a referenciából másoljuk át
                ref_df = reference_xls.parse(sheet)
                ref_df.to_excel(writer, sheet_name=sheet, index=False)

        # Új fájl mentése
        writer.save()

        # Ha vannak hiányzó oszlopok, jelezzük a felhasználónak
        if missing_columns:
            messagebox.showwarning("Hiányzó oszlopok", f"A kiválasztott fájlban nem léteznek ezek az oszlopok:\n" + "\n".join(missing_columns))
        else:
            messagebox.showinfo("Siker", "A fájl sikeresen módosítva lett és elmentve!")
    except Exception as e:
        messagebox.showerror("Hiba", f"Hiba történt a fájl feldolgozása során: {e}")

def browse_file():
    filepath = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if filepath:
        entry_file_path.delete(0, tk.END)
        entry_file_path.insert(0, filepath)

def execute_operation():
    filepath = entry_file_path.get()
    if filepath:
        process_file(reference_file='C:/Users/G3909/Desktop/VerConv/V3.1.8.xlsx', user_file=filepath)
    else:
        messagebox.showwarning("Figyelmeztetés", "Kérjük, adjon meg egy érvényes fájl útvonalat!")

# GUI létrehozása
root = tk.Tk()
root.title("Excel Adatmásoló")
root.geometry("500x200")

# Szövegdoboz az útvonal megadásához
entry_file_path = tk.Entry(root, width=50)
entry_file_path.pack(pady=20)

# Tallózás gomb
btn_browse = tk.Button(root, text="Tallózás", command=browse_file)
btn_browse.pack()

# Művelet végrehajtás gomb
btn_execute = tk.Button(root, text="Művelet végrehajtása", command=execute_operation)
btn_execute.pack(pady=20)

root.mainloop()
