import pyautogui
import time
from pywinauto.keyboard import send_keys

ertek='HU000220F11-S00000000000016305766'
# Funkció egy kép megtalálására és rákattintására
def find_and_click(image_path):
    location = pyautogui.locateOnScreen(image_path, confidence=0.8)  # Confidence érték finomhangolható
    if location is not None:
        pyautogui.click(pyautogui.center(location))
        print(f'Clicked on {image_path}')
    else:
        print(f'{image_path} not found on screen.')

# Kattintás a 'Más kereső kritériumok' fülre
find_and_click('C:\\Users\\G3909\\Desktop\\SAP_2\\mas kereso kriteriumok.png')
time.sleep(1)  # Vár egy kicsit, hogy az új fül betöltődjön

# Belépés a 'Mér.pont megn.' szövegmezőbe
find_and_click('C:\\Users\\G3909\\Desktop\\SAP_2\\mer pont megn.png')
send_keys(ertek)
time.sleep(5)  # Várakozás
send_keys('{ENTER}')
time.sleep(3)  # Várakozás
send_keys('^a')
send_keys('^c')
time.sleep(2)  # Várakozás
pyautogui.scroll(-4000)
find_and_click('C:\\Users\\G3909\\Desktop\\SAP_2\\idoszeletek.png')
time.sleep(1)
find_and_click('C:\\Users\\G3909\\Desktop\\SAP_2\\ukszeg.png')
send_keys('{DOWN}')
send_keys('^y')
send_keys('^c')
find_and_click('C:\\Users\\G3909\\Desktop\\SAP_2\\close.png')
time.sleep(2)
find_and_click('C:\\Users\\G3909\\Desktop\\SAP_2\\back.png')
time.sleep(3)
send_keys('^f')

