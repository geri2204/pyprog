from pywinauto import Desktop
import time
import keyboard  # Module to detect key presses

# Get the list of all windows
windows = Desktop(backend="win32").windows()
current_window_index = 0

def focus_next_window():
    global current_window_index
    if current_window_index < len(windows):
        window = windows[current_window_index]
        print(f"Window Title: {window.window_text()}")
        # Try to bring the window to the foreground
        try:
            window.set_focus()
            time.sleep(1)  # Wait for a moment to observe the window
        except Exception as e:
            print(f"Error focusing window: {e}")
        current_window_index += 1
    else:
        print("No more windows to display.")
g
print("Press 'G' to list the next window.")
while True:
    # Wait for the 'G' key to be pressed
    if keyboard.is_pressed('g'):
        focus_next_window()
        # Wait until the 'G' key is released to avoid multiple triggers
        while keyboard.is_pressed('g'):
            time.sleep(0.1)
