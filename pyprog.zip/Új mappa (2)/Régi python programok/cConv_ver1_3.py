import openpyxl
from copy import copy
import tkinter as tk
from tkinter import filedialog
import warnings

# Suppress specific openpyxl warnings
warnings.filterwarnings("ignore", category=UserWarning, module='openpyxl')

def select_source_file():
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    source_entry.delete(0, tk.END)
    source_entry.insert(0, file_path)

def select_target_file():
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    target_entry.delete(0, tk.END)
    target_entry.insert(0, file_path)

def perform_operation():
    source_file_path = source_entry.get()
    target_file_path = target_entry.get()

    # Load the source workbook and select the 'ALAP' worksheet
    print("Loading source workbook...")
    source_workbook = openpyxl.load_workbook(source_file_path)
    source_worksheet = source_workbook['ALAP']

    # Load the target workbook and select the 'ALAP' worksheet
    print("Loading target workbook...")
    target_workbook = openpyxl.load_workbook(target_file_path)
    target_worksheet = target_workbook['ALAP']

    # Get the maximum row in the source 'A', 'B', 'C' columns
    max_row = source_worksheet.max_row
    print(f"Max row in source worksheet: {max_row}")

    # Insert three new columns between 'AH' and 'AI'
    print("Inserting columns in target worksheet...")
    target_worksheet.insert_cols(35, amount=3)  # Column 'AH' is the 34th column

    # Copy data, style, and formulas from source to target
    print("Copying data from source to target...")
    for row in range(1, max_row + 1):
        for col_idx, target_col in enumerate(['AI', 'AJ', 'AK'], start=1):
            source_cell = source_worksheet.cell(row=row, column=col_idx)
            target_cell = target_worksheet[target_col + str(row)]

            # Copy value and formula
            if source_cell.data_type == 'f':
                target_cell.value = f"={source_cell.value}"  # Copying the formula as a string with '='
            else:
                target_cell.value = source_cell.value

            # Copy style
            for attr in ['font', 'border', 'fill', 'number_format', 'protection', 'alignment']:
                setattr(target_cell, attr, copy(getattr(source_cell, attr)))

            # Copy hyperlink if exists
            if source_cell.hyperlink:
                target_cell.hyperlink = copy(source_cell.hyperlink)

    print("Data copied successfully.")

    # Function to insert column D between columns A and B
    def insert_column_D_between_A_and_B(sheet):
        print(f"Inserting column D between A and B in sheet: {sheet.title}")
        # Insert a new column between 'A' and 'B'
        sheet.insert_cols(2)

        # Get the maximum row in the 'D' column to iterate through all the cells
        max_row = sheet.max_row
        print(f"Max row in {sheet.title}: {max_row}")

        # Iterate through the 'D' column and copy each cell's content, style, and formulas to the new column 'B'
        for row in range(1, max_row + 1):
            cell = sheet[f'D{row}']
            new_cell = sheet[f'B{row}']

            # Copy value and formula
            if cell.data_type == 'f':
                new_cell.value = f"={cell.value}"  # Copying the formula as a string with '='
            else:
                new_cell.value = cell.value

            # Copy style
            for attr in ['font', 'border', 'fill', 'number_format', 'protection', 'alignment']:
                setattr(new_cell, attr, copy(getattr(cell, attr)))

            # Copy hyperlink if exists
            if cell.hyperlink:
                new_cell.hyperlink = copy(cell.hyperlink)

        # Delete the original 'D' column
        sheet.delete_cols(4)
        print(f"Column D inserted and original column deleted in sheet: {sheet.title}")

    # Apply the function to the specified sheets in the target workbook
    for sheet_name in ['KOMMUNIKACIO (KAPCSOLATTARTO)', 'KOMMUNKIACIO (FOGYASZTO)']:
        if sheet_name in target_workbook.sheetnames:
            sheet = target_workbook[sheet_name]
            insert_column_D_between_A_and_B(sheet)

    # Save the modified target workbook with a new name
    new_target_file_path = target_file_path.replace('.xlsx', '_conv.xlsx')
    target_workbook.save(new_target_file_path)

    result_label.config(text=f"Módosított fájl elmentve ide: {new_target_file_path}")
    print(f"Modified file saved to: {new_target_file_path}")

# Create the main window
root = tk.Tk()
root.title("Excel Modifier")

# Create and place widgets
source_label = tk.Label(root, text="Forrás fájl:")
source_label.grid(row=0, column=0, padx=10, pady=5)
source_entry = tk.Entry(root, width=50)
source_entry.grid(row=0, column=1, padx=10, pady=5)
source_button = tk.Button(root, text="Tallózás", command=select_source_file)
source_button.grid(row=0, column=2, padx=10, pady=5)

target_label = tk.Label(root, text="Cél fájl:")
target_label.grid(row=1, column=0, padx=10, pady=5)
target_entry = tk.Entry(root, width=50)
target_entry.grid(row=1, column=1, padx=10, pady=5)
target_button = tk.Button(root, text="Tallózás", command=select_target_file)
target_button.grid(row=1, column=2, padx=10, pady=5)

run_button = tk.Button(root, text="Módosítás végrehajtása", command=perform_operation)
run_button.grid(row=2, column=0, columnspan=3, pady=10)

result_label = tk.Label(root, text="")
result_label.grid(row=3, column=0, columnspan=3, pady=10)

# Run the main event loop
root.mainloop()
