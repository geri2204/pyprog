from pywinauto import Desktop

# List all open windows and their titles
for window in Desktop(backend="win32").windows():
    print(window.window_text())
