import tkinter as tk
from tkinter import filedialog, messagebox
import xml.etree.ElementTree as ET

def swap_tags():
    file_path = file_path_entry.get()
    tag_to_move = tag_to_move_entry.get()
    tag_before = tag_before_entry.get()
    
    if not file_path or not tag_to_move or not tag_before:
        messagebox.showerror("Hiba", "Minden mezőt ki kell tölteni!")
        return
    
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
        
        # Find all parent elements that contain both tags
        for parent in root.iter():
            tag_to_move_elements = parent.findall(tag_to_move)
            tag_before_elements = parent.findall(tag_before)
            
            if not tag_to_move_elements or not tag_before_elements:
                continue
            
            for tag_to_move_elem in tag_to_move_elements:
                for tag_before_elem in tag_before_elements:
                    # Check if the tags are not in the correct order
                    if list(parent).index(tag_to_move_elem) > list(parent).index(tag_before_elem):
                        parent.remove(tag_to_move_elem)
                        parent.insert(list(parent).index(tag_before_elem), tag_to_move_elem)
        
        tree.write(file_path)
        messagebox.showinfo("Siker", "A tagek sikeresen fel lettek cserélve.")
    
    except Exception as e:
        messagebox.showerror("Hiba", f"Hiba történt: {str(e)}")

app = tk.Tk()
app.title("XML Tag Felcserélő")

tk.Label(app, text="Fájl elérési útja:").grid(row=0, column=0, padx=10, pady=10)
file_path_entry = tk.Entry(app, width=150)
file_path_entry.grid(row=0, column=1, padx=10, pady=10)

tk.Label(app, text="Mozgatandó tag:").grid(row=1, column=0, padx=10, pady=10)
tag_to_move_entry = tk.Entry(app, width=150)
tag_to_move_entry.grid(row=1, column=1, padx=10, pady=10)

tk.Label(app, text="Cél tag (ez elé mozgatjuk):").grid(row=2, column=0, padx=10, pady=10)
tag_before_entry = tk.Entry(app, width=150)
tag_before_entry.grid(row=2, column=1, padx=10, pady=10)

swap_button = tk.Button(app, text="Tagek felcserélése", command=swap_tags)
swap_button.grid(row=3, column=0, columnspan=2, pady=10)

app.mainloop()
