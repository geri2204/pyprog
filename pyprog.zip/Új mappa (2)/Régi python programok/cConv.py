# Load the workbook and select the 'ALAP' worksheet
file_path = '\\Users\\G3909\\Desktop\\minta3.1.8.xlsx'
import openpyxl
from copy import copy
workbook = openpyxl.load_workbook(file_path)
worksheet = workbook['ALAP']

# Insert a new column between 'B' and 'C'
worksheet.insert_cols(3)

# Get the maximum row in the 'A' column to iterate through all the cells
max_row = worksheet.max_row

# Iterate through the 'A' column and copy each cell's content, style, and formulas to the new column 'C'
for row in range(1, max_row + 1):
    cell = worksheet[f'A{row}']
    new_cell = worksheet[f'C{row}']
    
    # Copy value and formula
    if cell.data_type == 'f':
        new_cell.value = f"={cell.value}"  # Copying the formula as a string with '='
    else:
        new_cell.value = cell.value
    
    # Copy style
    for attr in ['font', 'border', 'fill', 'number_format', 'protection', 'alignment']:
        setattr(new_cell, attr, copy(getattr(cell, attr)))
    
    # Copy hyperlink if exists
    if cell.hyperlink:
        new_cell.hyperlink = copy(cell.hyperlink)

# Delete the original 'A' column
worksheet.delete_cols(1)

# Save the modified workbook with a new name
new_file_path = 'C:\\Users\\G3909\\Desktop\\minta3.1.8_conv.xlsx'
workbook.save(new_file_path)

new_file_path
