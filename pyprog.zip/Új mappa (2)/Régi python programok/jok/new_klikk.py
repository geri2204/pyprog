from pywinauto import Desktop
import time
from pywinauto.keyboard import send_keys

# Replace this with the exact title or partial title of the window you're interested in
target_title = "EMP(1)/102 Bekötés megjelenítése: kezdő kép"

# Find the target window and set focus
window = None
for win in Desktop(backend="win32").windows():
    if target_title in win.window_text():
        window = win
        break

if window:
    print(f"Found target window: {window.window_text()}")
    window.set_focus()
    time.sleep(2)  # Observe the target window

    # Send Ctrl+F key combination
    send_keys('^f')  # '^' is the symbol for Ctrl

    print("Ctrl+F key combination sent.")
else:
    print("Target window not found.")

print("Finished processing windows.")
