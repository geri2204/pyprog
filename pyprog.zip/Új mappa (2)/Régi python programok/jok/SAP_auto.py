from pywinauto import Desktop
import time
from pywinauto.keyboard import send_keys
from pywinauto.mouse import click

# Replace this with the exact title or partial title of the window you're interested in
target_title = "EMP(1)/102 Bekötés megjelenítése: kezdő kép"
data_finder_title = "EMP(1)/102 Data Finder(adatkereső): Közműbekötés keresése"

# Find the target window and set focus
window = None
for win in Desktop(backend="win32").windows():
    if target_title in win.window_text():
        window = win
        break

if window:
    print(f"Found target window: {window.window_text()}")
    window.set_focus()
    time.sleep(2)  # Observe the target window

    # Send Ctrl+F key combination
    send_keys('^f')  # '^' is the symbol for Ctrl
    print("Ctrl+F key combination sent.")
else:
    print("Target window not found.")
    exit()

# Wait for the Data Finder window to appear
time.sleep(5)

# Find the Data Finder window and set focus
data_finder_window = None
for win in Desktop(backend="win32").windows():
    if data_finder_title in win.window_text():
        data_finder_window = win
        break

if data_finder_window:
    print(f"Found Data Finder window: {data_finder_window.window_text()}")
    data_finder_window.set_focus()
    time.sleep(2)  # Observe the target window

    # Assume the menu is a part of the window and we need to click on the 3rd menu item
    # This can be done by navigating through the UI elements or sending appropriate key presses
    # Here we use a dummy coordinate click, adjust the coordinates as necessary
    menu_coords = (100, 50)  # Example coordinates; you need to find the exact coordinates for the menu
    click(coords=menu_coords)
    print("Clicked on the 3rd menu item.")
else:
    print("Data Finder window not found.")

print("Finished processing windows.")
