#import pandas as pd
import openpyxl
import tkinter as tk
from tkinter import filedialog, messagebox

def process_file(file_path, agent, old_values, new_values):
    # Load the Excel file
    workbook = openpyxl.load_workbook(file_path)
    
    # Define the sheets to be processed
    sheets_to_process = ['ALAP', 'CSATLAKOZASI_PONT_ADATOK', 'SPEC_JELLEMZOK', 
                         'TERMEK_MENNYISEG', 'KOMMUNIKACIO (KAPCSOLATTARTO)', 
                         'KOMMUNIKACIO (FOGYASZTO)']
    
    # Read old and new values from text widgets
    old_values = old_values.strip().split('\n')
    new_values = new_values.strip().split('\n')
    
    if len(old_values) != len(new_values):
        messagebox.showerror("Error", "Old values and new values must have the same number of entries.")
        return

    value_map = dict(zip(old_values, new_values))
    
    # Process each sheet
    for sheet_name in sheets_to_process:
        if sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            for row in sheet.iter_rows(min_row=2, min_col=1, max_col=1):
                cell = row[0]
                if cell.value in value_map:
                    cell.value = value_map[cell.value]
                    
            # Add 'UB1' to column 'B' if 'A' has data (only for 'ALAP' sheet)
            if sheet_name == 'ALAP':
                for row in sheet.iter_rows(min_row=2, min_col=1, max_col=2):
                    cell_a = row[0]
                    cell_b = row[1]
                    if cell_a.value is not None:
                        cell_b.value = 'UB1'
    
    # Save the new file with the appropriate suffix
    suffix = '_HG' if agent == 'Hafner Gergő' else '_KB'
    new_file_path = file_path.replace(".xlsx", f"{suffix}.xlsx")
    workbook.save(new_file_path)
    messagebox.showinfo("Success", f"File processed and saved as {new_file_path}")

def open_file():
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if file_path:
        file_path_var.set(file_path)

def run_processing():
    file_path = file_path_var.get()
    if not file_path:
        messagebox.showerror("Error", "Please select a file.")
        return
    
    agent = agent_var.get()
    old_values = old_values_text.get("1.0", tk.END)
    new_values = new_values_text.get("1.0", tk.END)
    
    if not old_values.strip() or not new_values.strip():
        messagebox.showerror("Error", "Please enter both old and new values.")
        return
    
    process_file(file_path, agent, old_values, new_values)

# Create the main window
root = tk.Tk()
root.title("Excel File Processor")

# File selection
file_path_var = tk.StringVar()
tk.Label(root, text="Select Excel file:").grid(row=0, column=0, padx=10, pady=5)
tk.Entry(root, textvariable=file_path_var, width=50).grid(row=0, column=1, padx=10, pady=5)
tk.Button(root, text="Browse", command=open_file).grid(row=0, column=2, padx=10, pady=5)

# Agent selection
tk.Label(root, text="Select agent:").grid(row=1, column=0, padx=10, pady=5)
agent_var = tk.StringVar()
agent_var.set("Hafner Gergő")
tk.OptionMenu(root, agent_var, "Hafner Gergő", "Kálló Bence").grid(row=1, column=1, padx=10, pady=5)

# Old values
tk.Label(root, text="Old values:").grid(row=2, column=0, padx=10, pady=5)
old_values_text = tk.Text(root, height=10, width=25)
old_values_text.grid(row=2, column=1, padx=10, pady=5)

# New values
tk.Label(root, text="New values:").grid(row=2, column=2, padx=10, pady=5)
new_values_text = tk.Text(root, height=10, width=25)
new_values_text.grid(row=2, column=3, padx=10, pady=5)

# Process button
tk.Button(root, text="Process", command=run_processing).grid(row=3, column=1, columnspan=2, pady=10)

root.mainloop()
