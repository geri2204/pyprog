import tkinter as tk
from tkinter import filedialog, messagebox
import xml.etree.ElementTree as ET

def browse_file():
    file_path = filedialog.askopenfilename(filetypes=[("XML files", "*.xml")])
    if file_path:
        file_path_entry.delete(0, tk.END)
        file_path_entry.insert(0, file_path)

def swap_tags():
    file_path = file_path_entry.get()
    tag_to_move = tag_to_move_entry.get()
    tag_before = tag_before_entry.get()
    
    if not file_path or not tag_to_move or not tag_before:
        messagebox.showerror("Hiba", "Minden mezőt ki kell tölteni!")
        return
    
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
        
        changes_made = False
        
        for parent in root.iter():
            children = list(parent)
            tag_to_move_indices = [i for i, child in enumerate(children) if child.tag == tag_to_move]
            tag_before_indices = [i for i, child in enumerate(children) if child.tag == tag_before]
            
            for move_index in tag_to_move_indices:
                for before_index in tag_before_indices:
                    if move_index > before_index:
                        tag_to_move_elem = children[move_index]
                        parent.remove(tag_to_move_elem)
                        parent.insert(before_index, tag_to_move_elem)
                        changes_made = True
        
        if changes_made:
            tree.write(file_path)
            messagebox.showinfo("Siker", "A tagek sikeresen fel lettek cserélve.")
        else:
            messagebox.showinfo("Információ", "Nem történt változtatás, a tagek már megfelelő sorrendben voltak.")
    
    except Exception as e:
        messagebox.showerror("Hiba", f"Hiba történt: {str(e)}")

app = tk.Tk()
app.title("XML Tag Felcserélő")

tk.Label(app, text="Fájl elérési útja:").grid(row=0, column=0, padx=10, pady=10)
file_path_entry = tk.Entry(app, width=50)
file_path_entry.grid(row=0, column=1, padx=10, pady=10)
browse_button = tk.Button(app, text="Tallózás", command=browse_file)
browse_button.grid(row=0, column=2, padx=10, pady=10)

tk.Label(app, text="Mozgatandó tag:").grid(row=1, column=0, padx=10, pady=10)
tag_to_move_entry = tk.Entry(app, width=50)
tag_to_move_entry.grid(row=1, column=1, padx=10, pady=10)

tk.Label(app, text="Cél tag (ez elé mozgatjuk):").grid(row=2, column=0, padx=10, pady=10)
tag_before_entry = tk.Entry(app, width=50)
tag_before_entry.grid(row=2, column=1, padx=10, pady=10)

swap_button = tk.Button(app, text="Tagek felcserélése", command=swap_tags)
swap_button.grid(row=3, column=0, columnspan=3, pady=10)

app.mainloop()
