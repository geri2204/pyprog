import tkinter as tk
from tkinter import ttk
import os
import shutil
from datetime import datetime
import openpyxl
from openpyxl import load_workbook

# Gombnyomás esemény kezelő: Beküld
def submit_button_click():
    name = name_entry.get()  # Ügyintéző nevének beolvasása az input mezőből
    code = code_entry.get()  # Ügyintéző kódjának beolvasása az input mezőből

    # Monogram készítése
    name_parts = name.split()  # Ügyintéző teljes nevének szétbontása szóköz mentén
    monogram = ''.join([part[0].upper() for part in name_parts])  # Monogram létrehozása

    # Üzenet megjelenítése
    result_label.config(text=f"Hello, {name}! A monogramod: {monogram}")  # Eredmény kiírása a GUI-ba

    # Felhasználó által megadott mappa útvonala
    folder_path = folder_entry.get()  # Mappa útvonalának beolvasása az input mezőből

    # Meghatározzuk a formázott dátumot
    current_time = datetime.now().strftime("%Y%m%d_%H%M")  # Aktuális idő formázása

    # Mappa neve a formázott dátum alapján
    folder_name = f"{current_time}"  # Mappa nevének létrehozása a formázott időből

    # Teljes mappa útvonala
    folder_dir = os.path.join(folder_path, folder_name)  # Teljes mappa útvonal összeállítása

    # Ellenőrizzük, hogy létezik-e már a mappa, ha nem, létrehozzuk
    if not os.path.exists(folder_dir):  # Ha még nem létezik a mappa, létrehozzuk
        os.makedirs(folder_dir)
        print(f"A(z) '{folder_name}' nevű mappa létrehozva itt: '{folder_dir}'")
    else:  # Ha már létezik a mappa, erről tájékoztatjuk a felhasználót
        print(f"A(z) '{folder_name}' nevű mappa már létezik itt: '{folder_dir}'")

    # Fájl útvonalának meghatározása a létrehozott mappában
    file_path = os.path.join(folder_dir, 'belep.txt')

    # Adatok írása a belep.txt fájlba
    with open(file_path, 'w') as file:  # Adatok írása a belep.txt fájlba
        file.write(f"Ügyintéző neve: {name}\n")
        file.write(f"Monogram: {monogram}\n")
        file.write(f"Kód: {code}\n")
        file.write(f"Dátum és idő: {current_time}\n")

# Gombnyomás esemény kezelő: Bemásol
def copy_button_click():
    # Felhasználó által megadott célmappa útvonala
    folder_path = folder_entry.get()  # Célmappa útvonalának beolvasása az input mezőből

    # Meghatározzuk a formázott dátumot
    current_time = datetime.now().strftime("%Y%m%d_%H%M")  # Aktuális idő formázása

    # Mappa neve a formázott dátum alapján
    folder_name = f"{current_time}"  # Mappa nevének létrehozása a formázott időből

    # Teljes mappa útvonala
    folder_dir = os.path.join(folder_path, folder_name)  # Teljes mappa útvonal összeállítása

    # Ellenőrizzük, hogy létezik-e a mappa
    if os.path.exists(folder_dir):  # Ha létezik a cél mappa
        # Felhasználó által választott forrás mappa útvonala
        source_folder = source_folder_entry.get()  # Forrás mappa útvonalának beolvasása

        # Ha a felhasználó nem adott meg forrás mappa útvonalat, hibát jelezünk
        if not source_folder:
            print("Kérem adjon meg egy forrás mappa útvonalat!")
            return

        # Ha a megadott mappa nem létezik, hibát jelezünk
        if not os.path.exists(source_folder):
            print(f"A(z) '{source_folder}' mappa nem létezik!")
            return

        try:
            # Iterálunk az összes fájlon és mappán a forrás mappában
            for item in os.listdir(source_folder):
                source_item = os.path.join(source_folder, item)
                target_item = os.path.join(folder_dir, item)

                # Ha fájl, akkor áthelyezzük
                if os.path.isfile(source_item):
                    shutil.move(source_item, target_item)
                    print(f"A {item} fájl áthelyezve ide: '{target_item}'")

                # Ha mappa, akkor rekurzívan áthelyezzük
                elif os.path.isdir(source_item):
                    shutil.move(source_item, target_item)
                    print(f"A {item} mappa áthelyezve ide: '{target_item}' (rekurzívan)")

        except Exception as e:
            print(f"Hiba történt az áthelyezés közben: {str(e)}")

    else:
        print(f"A(z) '{folder_name}' nevű mappa nem létezik itt: '{folder_dir}'")

# Gombnyomás esemény kezelő: Excel cella módosítása
def modify_excel_cell():
    file_path = excel_file_entry.get()  # Excel fájl útvonalának beolvasása az input mezőből
    cella = cell_entry.get()  # Cella beolvasása az input mezőből
    ertek = value_entry.get()  # Érték beolvasása az input mezőből

    # Ellenőrizni kell a fájl formátumát
    if not file_path.endswith(('.xlsx', '.xlsm', '.xltx', '.xltm')):
        excel_result_label.config(text="Nem támogatott fájlformátum!")
        return

    if not os.path.exists(file_path):
        excel_result_label.config(text="A megadott fájl nem létezik!")
        return

    try:
        # Munkafüzet betöltése
        book = load_workbook(file_path)
        sheet = book.active

        # Eredeti érték kiírása
        original_value = sheet[cella].value
        print(f"Eredeti érték a(z) {cella} cellában: {original_value}")

        # Cella értékének módosítása
        sheet[cella].value = ertek

        # Munkafüzet mentése ugyanabba a fájlba
        book.save(file_path)

        # Betöltés és ellenőrzés a mentés után
        book = load_workbook(file_path)
        sheet = book.active
        modified_value = sheet[cella].value
        print(f"Módosított érték a(z) {cella} cellában: {modified_value}")

        # Eredmény kiírása a GUI-ba
        excel_result_label.config(text=f"Módosított érték a(z) {cella} cellában: {modified_value}")

    except Exception as e:
        print(f"Hiba történt: {str(e)}")
        excel_result_label.config(text=f"Hiba történt: {str(e)}")


# Fő Tkinter ablak létrehozása
root = tk.Tk()
root.title("Ügyintéző adatok és fájl áthelyezés")

# Ikont beállítása
root.iconbitmap(r'C:\Users\G3909\Desktop\icon.ico')

# Notebook (tabok) létrehozása
notebook = ttk.Notebook(root)
notebook.pack(pady=10, expand=True)

# Fül 1: Adatok beküldése
frame1 = ttk.Frame(notebook, width=400, height=280)
frame1.pack(fill='both', expand=True)

# Fül 2: Fájl áthelyezés
frame2 = ttk.Frame(notebook, width=400, height=280)
frame2.pack(fill='both', expand=True)

# Fül 3: Excel cella módosítása
frame3 = ttk.Frame(notebook, width=400, height=280)
frame3.pack(fill='both', expand=True)

notebook.add(frame1, text='Adatok beküldése')
notebook.add(frame2, text='Fájl áthelyezés')
notebook.add(frame3, text='Excel cella módosítása')

# Fül 1: Adatok beküldése
folder_label = tk.Label(frame1, text="Mappa útvonala:")
folder_label.pack()
folder_entry = tk.Entry(frame1)
folder_entry.pack()

name_label = tk.Label(frame1, text="Az ügyintéző teljes neve:")
name_label.pack()
name_entry = tk.Entry(frame1)
name_entry.pack()

code_label = tk.Label(frame1, text="Az ügyintéző kódja:")
code_label.pack()
code_entry = tk.Entry(frame1)
code_entry.pack()

submit_button = tk.Button(frame1, text="Beküld", command=submit_button_click)
submit_button.pack()

result_label = tk.Label(frame1, text="")
result_label.pack()

# Fül 2: Fájl áthelyezés
source_folder_label = tk.Label(frame2, text="Forrás mappa útvonala:")
source_folder_label.pack()
source_folder_entry = tk.Entry(frame2)
source_folder_entry.pack()

copy_button = tk.Button(frame2, text="Bemásol", command=copy_button_click)
copy_button.pack()

# Fül 3: Excel cella módosítása
excel_file_label = tk.Label(frame3, text="Excel fájl útvonala:")
excel_file_label.pack()
excel_file_entry = tk.Entry(frame3)
excel_file_entry.pack()

cell_label = tk.Label(frame3, text="Cella:")
cell_label.pack()
cell_entry = tk.Entry(frame3)
cell_entry.pack()

value_label = tk.Label(frame3, text="Új érték:")
value_label.pack()
value_entry = tk.Entry(frame3)
value_entry.pack()

modify_button = tk.Button(frame3, text="Módosít", command=modify_excel_cell)
modify_button.pack()

excel_result_label = tk.Label(frame3, text="")
excel_result_label.pack()

# Tkinter fő eseményhurok
root.mainloop()
