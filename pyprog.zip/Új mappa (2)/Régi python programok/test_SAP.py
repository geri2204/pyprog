from pywinauto import Application, Desktop
import time
from pywinauto.keyboard import send_keys
from pywinauto.mouse import click

def identify_controls(window_title):
    window = None
    for win in Desktop(backend="win32").windows():
        if window_title in win.window_text():
            window = win
            break

    if window:
        print(f"Found window: {window.window_text()}")
        window.print_control_identifiers()
    else:
        print(f"Window with title '{window_title}' not found.")

def main():
    # Start the SAP Logon application
    app = Application(backend="win32").start(r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe")
    print("SAP Logon started. Waiting for the target window...")

    # Replace this with the exact title or partial title of the window you're interested in
    target_title = "EMP(1)/102 Bekötés megjelenítése: kezdő kép"

    # Wait for the target window to appear
    window = None
    while not window:
        for win in Desktop(backend="win32").windows():
            if target_title in win.window_text():
                window = win
                break
        time.sleep(1)

    if window:
        print(f"Found target window: {window.window_text()}")
        window.set_focus()
        time.sleep(2)  # Observe the target window

        # Identify controls in the current window
        identify_controls(window)

        # Send Ctrl+F key combination
        send_keys('^f')  # '^' is the symbol for Ctrl
        print("Ctrl+F key combination sent.")

        # New window title after Ctrl+F
        new_window_title = "EMP(1)/102 Data Finder(adatkereső): Közműbekötés keresése"
        window = None
        while not window:
            for win in Desktop(backend="win32").windows():
                if new_window_title in win.window_text():
                    window = win
                    break
            time.sleep(1)

        if window:
            print(f"Found new window: {window.window_text()}")
            window.set_focus()
            time.sleep(2)  # Observe the new window

            # Identify controls in the new window
            identify_controls(window)

            # Send Tab key, right arrow twice, and click
            send_keys('{TAB}')
            time.sleep(1)
            send_keys('{RIGHT}')
            time.sleep(1)
            send_keys('{RIGHT}')
            click(button='left', coords=None)

            print("Tab and right arrow keys pressed, click executed.")
        else:
            print("New window not found.")
    else:
        print("Target window not found.")

    print("Finished processing windows.")

if __name__ == "__main__":
    main()
