import openpyxl
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

# Globális változó a legutóbbi módosított fájl elérési útjához
modified_file_path = None

def process_file_replace(file_path, agent, old_values, new_values):
    global modified_file_path
    
    # Load the Excel file
    workbook = openpyxl.load_workbook(file_path)
    
    # Define the sheets to be processed
    sheets_to_process = ['ALAP', 'CSATLAKOZASI_PONT_ADATOK', 'SPEC_JELLEMZOK', 
                         'TERMEK_MENNYISEG', 'KOMMUNIKACIO (KAPCSOLATTARTO)', 
                         'KOMMUNIKACIO (FOGYASZTO)']
    
    # Read old and new values from text widgets
    old_values = old_values.strip().split('\n')
    new_values = new_values.strip().split('\n')
    
    if len(old_values) != len(new_values):
        messagebox.showerror("Error", "A jelenlegi referenciaszámok mennyisége megegyező kell, hogy legyen az új referenciaszámok mennyiségével!!")
        return

    value_map = dict(zip(old_values, new_values))
    
    # Process each sheet
    for sheet_name in sheets_to_process:
        if sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            for row in sheet.iter_rows(min_row=2, min_col=1, max_col=1):
                cell = row[0]
                if cell.value in value_map:
                    cell.value = value_map[cell.value]
                    
            # Add 'UB1' to column 'B' if 'A' has data (only for 'ALAP' sheet)
            if sheet_name == 'ALAP':
                for row in sheet.iter_rows(min_row=2, min_col=1, max_col=2):
                    cell_a = row[0]
                    cell_b = row[1]
                    if cell_a.value is not None:
                        cell_b.value = 'UB1'
    
    # Save the new file with the appropriate suffix
    suffix = '_HG' if agent == 'Hafner Gergő' else '_KB'
    modified_file_path = file_path.replace(".xlsx", f"{suffix}.xlsx")
    workbook.save(modified_file_path)
    messagebox.showinfo("SIKER!!", f"Fájl feldolgozva és másként elmentve: {modified_file_path}")

def open_file():
    file_path = filedialog.askopenfilename(filetypes=[("Excel fájlok", "*.xlsx")])
    if file_path:
        file_path_var.set(file_path)

def run_processing_replace():
    global modified_file_path
    
    file_path = file_path_var.get()
    if not file_path:
        messagebox.showerror("Error", "Először válaszd ki a fájlt!!")
        return
    
    agent = agent_var.get()
    old_values = old_values_text.get("1.0", tk.END)
    new_values = new_values_text.get("1.0", tk.END)
    
    if not old_values.strip() or not new_values.strip():
        messagebox.showerror("Error", "Add meg a jelenlegi referenciákat és az új referenciákat!!")
        return
    
    process_file_replace(file_path, agent, old_values, new_values)
    # Set the modified file path for the delete operation
    file_path_var.set(modified_file_path)

def process_file_generate(file_path, num_files, rows_to_include_list):
    # Load the original Excel file
    original_workbook = openpyxl.load_workbook(file_path)
    sheets_to_process = ['ALAP', 'CSATLAKOZASI_PONT_ADATOK', 'SPEC_JELLEMZOK', 
                         'TERMEK_MENNYISEG', 'KOMMUNIKACIO (KAPCSOLATTARTO)', 
                         'KOMMUNIKACIO (FOGYASZTO)']
    
    for i, rows_to_include in enumerate(rows_to_include_list, start=1):
        # Copy the original workbook to preserve other data
        workbook = openpyxl.load_workbook(file_path)
        
        for sheet_name in sheets_to_process:
            if sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
                # Get rows to keep based on values in column 'A'
                rows_to_keep = {int(row) for row in rows_to_include if row.isdigit()}
                rows_to_delete = []
                
                for row in sheet.iter_rows(min_row=2):
                    cell_value = row[0].value
                    if cell_value is not None and int(cell_value) not in rows_to_keep:
                        rows_to_delete.append(row[0].row)
                
                # Sort the rows in reverse order to avoid indexing issues when deleting
                for row in sorted(rows_to_delete, reverse=True):
                    sheet.delete_rows(row)
        
        new_file_path = file_path.replace(".xlsx", f"_{i}.xlsx")
        workbook.save(new_file_path)
    
    messagebox.showinfo("Success", "Fájlok sikeresen létrejöttek")

def generate_files():
    file_path = file_path_var.get()
    if not file_path:
        messagebox.showerror("Error", "Először válaszd ki a fájlt!!")
        return
    
    try:
        num_files = int(num_files_var.get())
    except ValueError:
        messagebox.showerror("Error", "Adj meg helyes sorszámot, vagy módosítandó fájlt!!")
        return
    
    rows_to_include_list = [text.get("1.0", tk.END).strip().split(';') for text in rows_to_include_texts]
    
    # Hívjuk meg a fájlgenerálást
    process_file_generate(file_path, num_files, rows_to_include_list)

def update_rows_to_include_entries():
    try:
        num_files = int(num_files_var.get())
    except ValueError:
        messagebox.showerror("Error", "Adj meg helyes sorszámot, vagy módosítandó fájlt!!")
        return
    
    for widget in rows_to_include_frame.winfo_children():
        widget.destroy()
    
    global rows_to_include_texts
    rows_to_include_texts = []
    for i in range(num_files):
        label = tk.Label(rows_to_include_frame, text=f"Ezeket a sorokat szeretném meghagyni a(z) {i+1}. fájlban:")
        label.pack()
        text = tk.Text(rows_to_include_frame, height=1, width=40)
        text.pack()
        rows_to_include_texts.append(text)

# Create the main window
root = tk.Tk()
root.title("UTILMD Fájl szerkesztő V3.0")

# Create tab control
tab_control = ttk.Notebook(root)
tab_replace = ttk.Frame(tab_control)
tab_delete = ttk.Frame(tab_control)
tab_control.add(tab_replace, text="Referenciaszám(ok) cserélése")
tab_control.add(tab_delete, text="Sorok szétbontása")
tab_control.pack(expand=1, fill="both")

# File selection for Replace References tab
file_path_var = tk.StringVar()
tk.Label(tab_replace, text="Excel fájl kiválasztása:").grid(row=0, column=0, padx=10, pady=5)
tk.Entry(tab_replace, textvariable=file_path_var, width=80).grid(row=0, column=1, padx=10, pady=5)
tk.Button(tab_replace, text="Tallózás", command=open_file).grid(row=0, column=2, padx=10, pady=5)

# Replace References tab
# Agent selection
tk.Label(tab_replace, text="Ügyintéző neve:").grid(row=1, column=0, padx=10, pady=5)
agent_var = tk.StringVar()
#agent_var.set("Hafner Gergő")
tk.OptionMenu(tab_replace, agent_var, "Hafner Gergő", "Kálló Bence").grid(row=1, column=1, padx=10, pady=5)

# Old values
tk.Label(tab_replace, text="Jelenlegi értékek (A oszlop):").grid(row=2, column=0, padx=10, pady=5)
old_values_text = tk.Text(tab_replace, height=30, width=25)
old_values_text.grid(row=2, column=1, padx=10, pady=5)

# New values
#tk.Label(tab_replace, text="Új értékek:").grid(row=2, column=2, padx=10, pady=5)
new_values_text = tk.Text(tab_replace, height=30, width=10)
new_values_text.grid(row=2, column=2, padx=10, pady=5)

# Process button for Replace References tab
tk.Button(tab_replace, text="Kicserél", command=run_processing_replace).grid(row=3, column=0, columnspan=4, pady=10)

# File selection for Delete Rows tab
tk.Label(tab_delete, text="Excel fájl kiválasztása (opcionális):").grid(row=0, column=0, padx=10, pady=5)
tk.Entry(tab_delete, textvariable=file_path_var, width=80).grid(row=0, column=1, padx=10, pady=5)
tk.Button(tab_delete, text="Tallózás", command=open_file).grid(row=0, column=2, padx=10, pady=5)

# Number of files to generate
tk.Label(tab_delete, text="Hány darab fájlra osztod szét? :").grid(row=1, column=0, padx=10, pady=5)
num_files_var = tk.StringVar()
tk.Entry(tab_delete, textvariable=num_files_var, width=5).grid(row=1, column=1, padx=10, pady=5)
tk.Button(tab_delete, text="FELOSZT!", command=update_rows_to_include_entries).grid(row=1, column=2, padx=10, pady=5)

# Frame for rows to include text entries
rows_to_include_frame = tk.Frame(tab_delete)
rows_to_include_frame.grid(row=2, column=0, columnspan=3, padx=10, pady=5)

# Generate files button
tk.Button(tab_delete, text="Felosztott fájlok generálása", command=generate_files).grid(row=3, column=0, columnspan=3, pady=10)

root.mainloop()
