from pywinauto import Application, Desktop
import time

def identify_controls(window):
    """Print control identifiers of the given window."""
    if window:
        try:
            window.print_control_identifiers()
        except Exception as e:
            print(f"Error identifying: {e}")
    else:
        print("Nincs mit identify-olni")

def wait_for_window(app, title_re, timeout=60):
    """Wait for a window with the specified title to appear within the application."""
    window = None
    start_time = time.time()
    while not window and time.time() - start_time < timeout:
        window = app.window(title_re=title_re)
        if not window.exists():
            window = None
        time.sleep(1)
    return window

def main():
    # Elindítja a SAP Logon alkalmazást
    app = Application(backend="win32").start(r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe")
    print("SAP Logon elindult. Várakozás a célablakra...")

    # Várakozás az első célablakra
    saplogon_title = "SAP Logon.*"
    saplogon = wait_for_window(app, saplogon_title)
    
    if saplogon:
        print(f"Célablak megtalálva: {saplogon.window_text()}")
        saplogon.set_focus()
        identify_controls(saplogon)
    else:
        print("Célablak nem található.")
        return

    # Kiválaszt egy rendszert a listából (például az elsőt)
    system_list = saplogon.child_window(title="Systems", control_type="List")
    system_list.select(6)

    # Kattint a 'Logon' gombra
    logon_button = saplogon.child_window(title="Logon", control_type="Button")
    logon_button.click()

    # Folyamatosan figyeli az új ablakokat és azonosítja a vezérlőelemeket
    previous_windows = set()
    while True:
        current_windows = {win.window_text() for win in Desktop(backend="win32").windows()}
        new_windows = current_windows - previous_windows
        
        for win_text in new_windows:
            window = app.window(title=win_text)
            if window.exists():
                print(f"Új ablak megtalálva: {win_text}")
                window.set_focus()
                identify_controls(window)
        
        previous_windows = current_windows
        time.sleep(5)  # Várakozás az új ablakok megjelenésére

if __name__ == "__main__":
    main()
