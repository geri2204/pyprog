import time
import tkinter as tk
from tkinter import Label
import cv2
import numpy as np
import pyautogui
import psutil
from PIL import Image, ImageTk

# Képek mappa elérési útja
images_path = r"C:\\Users\\G3909\\Desktop\\Incredible_excel\\pics"

# Képek hozzárendelése az időtartamokhoz
images = {
    'k12.png': 1.50,
    'k11.png': 2,
    'k10.png': 2.50,
    'k9.png': 3,
    'k8.png': 3.50,
    'zero.jpeg': 4,
    'k6.jpeg': 4.50,
    'k5.jpeg': 5,
    'k4.jpeg': 5.50,
    'k3.jpeg': 6,
    'k2.jpeg': 6.50,
    'k1.jpeg': 100,
}

def get_image_name(elapsed_time):
    for image, max_time in images.items():
        if elapsed_time <= max_time:
            return image
    return 'k1.png'  # Default image if time exceeds all thresholds

def image_exists(target_image_path):
    print(f"Checking for image: {target_image_path}")
    # Képernyőkép készítése
    screenshot = pyautogui.screenshot()
    screenshot_np = np.array(screenshot)

    # Célkép betöltése és konvertálása
    target_image = cv2.imread(target_image_path)
    target_gray = cv2.cvtColor(target_image, cv2.COLOR_BGR2GRAY)
    
    # Képernyőkép konvertálása
    screen_gray = cv2.cvtColor(screenshot_np, cv2.COLOR_BGR2GRAY)
    
    # Képkeresés a képernyőképen
    result = cv2.matchTemplate(screen_gray, target_gray, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(result)
    
    found = max_val > 0.8  # Threshold for match quality
    print(f"Image {'found' if found else 'not found'}")
    return found

def wait_for_excel_and_measure_time():
    print("Waiting for Excel to start...")
    excel_found = False
    start_time = None

    while True:
        for proc in psutil.process_iter(['pid', 'name']):
            if proc.info['name'].lower() == 'excel.exe':
                if not excel_found:
                    start_time = time.time()
                    excel_found = True
                    print("Excel started. Timer started.")
                # Ellenőrizzük, hogy a 'megjelent.png' kép megjelent-e
                if start_time and image_exists(r"C:\\Users\\G3909\\Desktop\\Incredible_excel\\pics\\megjelent.png"):
                    end_time = time.time()
                    elapsed_time = end_time - start_time
                    print(f"Excel fully loaded. Elapsed time: {elapsed_time:.2f} seconds")
                    return elapsed_time
        time.sleep(1)  # Várakozás a következő ellenőrzés előtt

def show_result(elapsed_time):
    print(f"Showing result for elapsed time: {elapsed_time:.2f} seconds")
    # GUI létrehozása
    result_window = tk.Tk()
    result_window.title("Excel Loading Time")
    
    # Az ablak mindig a legfelső rétegben
    result_window.attributes('-topmost', True)

    # Grid elrendezés beállítása
    result_window.grid_rowconfigure(0, weight=1)
    result_window.grid_rowconfigure(1, weight=1)
    result_window.grid_columnconfigure(0, weight=1)

    # Az eltelt idő megjelenítése
    time_label = Label(result_window, text=f"Elapsed Time: {elapsed_time:.2f} seconds")
    time_label.grid(row=0, column=0, padx=10, pady=10)

    # Kép kiválasztása és megjelenítése
    image_name = get_image_name(elapsed_time)
    image_path = f"{images_path}\\{image_name}"
    print(f"Loading image: {image_path}")
    img = Image.open(image_path)
    
    # Kép átméretezése 250x250-ra
    img = img.resize((250, 250), Image.LANCZOS)
    photo = ImageTk.PhotoImage(img)

    image_label = Label(result_window, image=photo)
    image_label.image = photo  # Keep a reference!
    image_label.grid(row=1, column=0, padx=10, pady=10)

    # Az ablak mindig a legfelső rétegben
    result_window.lift()
    result_window.mainloop()

def start_measurement():
    elapsed_time = wait_for_excel_and_measure_time()
    show_result(elapsed_time)

# Mérés elindítása GUI nélkül
start_measurement()
