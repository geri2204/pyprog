import os
import glob
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
import xml.etree.ElementTree as ET
from openpyxl import load_workbook

class FileSearcher:
    def __init__(self, root):
        self.root = root
        self.root.title("Fájl kereső")
        
        # Keresési szöveg mező
        tk.Label(root, text="Keresési szöveg:").grid(row=0, column=0, padx=10, pady=10)
        self.search_text = tk.Entry(root, width=50)
        self.search_text.grid(row=0, column=1, padx=10, pady=10)
        
        # Mappaútvonal mező
        tk.Label(root, text="Keresési mappa:").grid(row=1, column=0, padx=10, pady=10)
        self.folder_path = tk.Entry(root, width=50)
        self.folder_path.grid(row=1, column=1, padx=10, pady=10)
        
        # Keresés gomb
        search_button = tk.Button(root, text="Keresés", command=self.search_files)
        search_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)
        
        # Eredmény szövegdoboz
        self.result_text = scrolledtext.ScrolledText(root, width=80, height=20)
        self.result_text.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

    def search_files(self):
        search_term = self.search_text.get()
        folder = self.folder_path.get()
        
        if not search_term or not folder:
            self.result_text.insert(tk.END, "Kérlek, add meg a keresési szöveget és a mappaútvonalat.\n")
            return
        
        self.result_text.delete(1.0, tk.END)
        results = []

        for file in glob.glob(os.path.join(folder, '**/*'), recursive=True):
            if os.path.isfile(file):
                try:
                    if file.lower().endswith('.xml'):
                        results.extend(self.search_in_xml(file, search_term))
                    elif file.lower().endswith('.xlsx'):
                        results.extend(self.search_in_xlsx(file, search_term))
                except Exception as e:
                    results.append(f"Nem sikerült ellenőrizni a következő fájlt: {file} - Hiba: {str(e)}")
        
        if results:
            self.result_text.insert(tk.END, "\n".join(results))
        else:
            self.result_text.insert(tk.END, "A keresett szöveg nem található a megadott mappában.\n")

    def search_in_xml(self, file, search_term):
        results = []
        try:
            tree = ET.parse(file)
            root = tree.getroot()
            if self.search_in_element(root, search_term):
                results.append(f"Szöveg található a fájlban: {file}")
        except ET.ParseError:
            results.append(f"XML hiba: {file}")
        return results

    def search_in_element(self, element, search_term):
        if search_term in (element.text or ''):
            return True
        for child in element:
            if self.search_in_element(child, search_term):
                return True
        return False

    def search_in_xlsx(self, file, search_term):
        results = []
        try:
            workbook = load_workbook(filename=file, data_only=True)
            for sheet in workbook.sheetnames:
                worksheet = workbook[sheet]
                for row in worksheet.iter_rows(values_only=True):
                    if any(search_term in str(cell) for cell in row if cell is not None):
                        results.append(f"Szöveg található a fájlban: {file}")
                        break
        except Exception as e:
            results.append(f"Excel hiba: {file} - Hiba: {str(e)}")
        return results

if __name__ == "__main__":
    root = tk.Tk()
    app = FileSearcher(root)
    root.mainloop()
