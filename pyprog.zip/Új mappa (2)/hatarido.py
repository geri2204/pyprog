import tkinter as tk
from tkinter import scrolledtext
from openpyxl import load_workbook, Workbook
from openpyxl.styles import PatternFill
from datetime import datetime
import random

def load_data():
    # Az Excel fájl betöltése
    path = r'\\mvmh.local\dfs\Tagvallalatok\EHEL\TEAMS\100_GI\130_EFO\132_EFO_EFO\6_ADATCSERE\Átmeneti adatcsere\SZUMMA_tabla_atmeneti_ugyrend_kezelese.xlsx'
    workbook = load_workbook(filename=path, data_only=True)
    sheet = workbook['SZUMMA']
    
    # Az adatok kigyűjtése
    global highlighted_data
    highlighted_data = []

    data_list = []
    for row in sheet.iter_rows(min_row=3, max_row=sheet.max_row, values_only=True):
        if row[29] is None and row[17] != 'IK' and row[7] != 'Válasz':  # AD oszlop, R oszlop és H oszlop ellenőrzése
            record = {
                'Sorszám': row[5],     # F oszlop
                'Dátum': str(row[6])[:10],  # G oszlop, az első 10 karakter
                'Státusz': row[7],     # H oszlop
                'Típus': row[16],      # Q oszlop
                'Kiküldés dátuma': str(row[25])[:10],  # Z oszlop
                'Név': row[23],        # X oszlop
                'E-mail': row[24],     # Y oszlop
            }
            data_list.append(record)
    
    # Az adatsorok megjelenítése a szövegdobozban
    text_box.delete(1.0, tk.END)
    valid_count = 0
    today = datetime.today()

    for record in data_list:
        record_date = datetime.strptime(record['Dátum'], '%Y-%m-%d')
        if (today - record_date).days > 30:
            text_box.insert(tk.END, f"{record['Sorszám']}\t\t\t", 'highlight')
            highlighted_data.append(record)
        else:
            text_box.insert(tk.END, f"{record['Sorszám']}\t\t\t")
        text_box.insert(tk.END, f"{record['Dátum']}\t\t   ")
        text_box.insert(tk.END, f"{record['Státusz']}\t\t\t")
        text_box.insert(tk.END, f"{record['Típus']}\t\t\t\t\t")
        text_box.insert(tk.END, f"{record['Kiküldés dátuma']}\t\t\t")
        text_box.insert(tk.END, f"{record['Név']}\t\t\t")
        text_box.insert(tk.END, f"{record['E-mail']}\n")
        valid_count += 1
        text_box.insert(tk.END, "-"*180 + "\n")

    # Számláló frissítése
    count_label.config(text=f"Adatsorok száma: {valid_count}")

def export_to_excel():
    if not highlighted_data:
        return  # Ha nincs kiemelt adat, kilépünk a funkcióból
    
    # Új Excel fájl létrehozása vagy meglévő megnyitása
    output_path = r'C:\Users\G3909\Desktop\valaszuzenetek_kerese.xlsx'
    
    try:
        workbook = load_workbook(output_path)
    except FileNotFoundError:
        workbook = Workbook()

    sheet = workbook.active
    sheet.title = "Adatok"
    
    # Töröljük a meglévő adatokat az A4:G4 tartományban
    for row in range(4, sheet.max_row + 1):
        for col in range(1, 8):
            sheet.cell(row=row, column=col).value = None
    
    # Pasztell színek létrehozása
    def generate_pastel_color():
        r = lambda: random.randint(150, 255)
        return PatternFill(start_color=f'{r():02X}{r():02X}{r():02X}', end_color=f'{r():02X}{r():02X}{r():02X}', fill_type="solid")
    
    color_map = {}
    current_row = 4

    for record in highlighted_data:
        name = record['Név']
        if name not in color_map:
            color_map[name] = generate_pastel_color()

        fill = color_map[name]

        sheet[f'A{current_row}'].value = record['Sorszám']
        sheet[f'B{current_row}'].value = record['Dátum']
        sheet[f'C{current_row}'].value = record['Státusz']
        sheet[f'D{current_row}'].value = record['Típus']
        sheet[f'E{current_row}'].value = record['Kiküldés dátuma']
        sheet[f'F{current_row}'].value = record['Név']
        sheet[f'G{current_row}'].value = record['E-mail']

        for col in range(1, 8):
            sheet.cell(row=current_row, column=col).fill = fill
        
        current_row += 1
    
    # Fájl mentése
    workbook.save(output_path)

# GUI létrehozása
root = tk.Tk()
root.title("Excel Adatgyűjtő")

# Címsorok létrehozása
labels = [
    ('Sorszám:', 13), 
    ('Dátum:', 5),  # Csökkentett szélesség
    ('Státusz:', 10),  # Csökkentett szélesség
    ('Típus:', 25), 
    ('Kiküldés dátuma:', 13), 
    ('Név:', 13), 
    ('E-mail:', 13)
]

for i, (label_text, width) in enumerate(labels):
    label = tk.Label(root, text=label_text, width=width, anchor='w')  # Balra igazítás 'anchor=w' segítségével
    label.grid(row=0, column=i, sticky='w')  # A 'sticky=w' segítségével a bal oldalra helyezzük a címkét

# Szövegdoboz létrehozása az adatok megjelenítésére
text_box = scrolledtext.ScrolledText(root, width=180, height=40, wrap=tk.NONE)  # wrap=tk.NONE megadása a horizontális görgetéshez
text_box.grid(row=1, column=0, columnspan=len(labels), padx=10, pady=10)

# Szövegdoboz formázása
text_box.tag_config('highlight', background='yellow')

# Horizontális görgetősáv létrehozása
x_scrollbar = tk.Scrollbar(root, orient=tk.HORIZONTAL, command=text_box.xview)
x_scrollbar.grid(row=2, column=0, columnspan=len(labels), sticky='ew')

# A horizontális görgetés engedélyezése a szövegdobozban
text_box.config(xscrollcommand=x_scrollbar.set)

# Számláló címke létrehozása
count_label = tk.Label(root, text="Adatsorok száma: 0", anchor='w')
count_label.grid(row=3, column=0, sticky='w')

# Betöltés gomb létrehozása
load_button = tk.Button(root, text="Adatok betöltése", command=load_data)
load_button.grid(row=3, column=5, sticky='e')  # A gombot a számláló mellett helyezzük el

# Excelbe illesztés gomb létrehozása
export_button = tk.Button(root, text="Excelbe illeszt", command=export_to_excel)
export_button.grid(row=3, column=6, sticky='e')  # A gombot a betöltés gomb mellett helyezzük el

root.mainloop()
